package ru.maksimova;

public class ObjectMapper {
}
